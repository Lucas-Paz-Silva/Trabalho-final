-- ----------------------------------------------------------------------------
-- MySQL Workbench Migration
-- Migrated Schemata: tcc
-- Source Schemata: tcc
-- Created: Sun Oct 30 23:20:39 2022
-- Workbench Version: 8.0.31
-- ----------------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Schema tcc
-- ----------------------------------------------------------------------------
DROP SCHEMA IF EXISTS `tcc` ;
CREATE SCHEMA IF NOT EXISTS `tcc` ;

-- ----------------------------------------------------------------------------
-- Table tcc.grupo
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc`.`grupo` (
  `GRUPO` VARCHAR(45) NOT NULL,
  `EMAIL` VARCHAR(45) NOT NULL,
  `SENHA` VARCHAR(105) NOT NULL,
  `TURMA` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`GRUPO`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

-- ----------------------------------------------------------------------------
-- Table tcc.professor
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tcc`.`professor` (
  `NOME` VARCHAR(45) NOT NULL,
  `SENHA` VARCHAR(45) NOT NULL,
  `EMAIL` VARCHAR(105) NOT NULL,
  PRIMARY KEY (`NOME`))
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;
SET FOREIGN_KEY_CHECKS = 1;
